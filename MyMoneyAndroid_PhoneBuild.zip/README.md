# My Money Android project

This is an Android Studio project source (not an APK yet).

Features:
- Burmese / English toggle
- First-launch 4–6 digit PIN
- Income and expense entries
- Running balance and current-month totals
- Local on-device storage
- JSON backup export and restore
- Offline operation; no internet permission is requested

## Build from a phone using GitHub Actions
1. Create a GitHub account and a new **public** repository named `MyMoneyAndroid`.
2. Extract this ZIP on your phone.
3. In the repository website, upload the extracted project files and folders (including the hidden `.github/workflows/android.yml` file) to the `main` branch. If the mobile upload page cannot upload folders, use a browser's desktop-site mode or a GitHub-compatible mobile Git client.
4. Open the repository's **Actions** tab and select **Build My Money APK**. Tap **Run workflow** if it has not started automatically.
5. When the run finishes, open it and download the `MyMoney-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Open `app-debug.apk` on your Android phone and allow installation from that source if Android asks.

You can keep the repository private instead; public is only simpler for first-time setup. Never share your GitHub password or PIN.

## Build on a computer
Open this folder in Android Studio and build `app` > `assembleDebug`, or run `gradle :app:assembleDebug` with JDK 17 and Gradle 8.9.

Important:
- This is source code, not a prebuilt APK.
- PIN protection in this starter is a basic app lock, not strong encryption.
- Keep backup files safe. Test with sample records before relying on it for important financial records.
