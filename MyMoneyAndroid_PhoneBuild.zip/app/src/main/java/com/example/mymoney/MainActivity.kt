package com.example.mymoney

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val type: String, val amount: Long, val category: String, val note: String, val date: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mymoney_local", MODE_PRIVATE) }
    private val entries = mutableListOf<Entry>()
    private lateinit var root: LinearLayout
    private var english = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!pinGate()) return
        loadEntries()
        showHome()
    }

    private fun pinGate(): Boolean {
        val saved = prefs.getString("pin", null)
        if (saved == null) {
            val input = EditText(this).apply {
                hint = "Create 4-6 digit PIN"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this).setTitle("My Money – Create PIN")
                .setMessage("Create a PIN to protect your money records.")
                .setView(input).setCancelable(false)
                .setPositiveButton("Save") { _, _ ->
                    val pin = input.text.toString()
                    if (pin.length in 4..6) {
                        prefs.edit().putString("pin", pin).apply()
                        loadEntries()
                        showHome()
                    } else {
                        Toast.makeText(this, "PIN must be 4–6 digits. Reopen app to try again.", Toast.LENGTH_LONG).show()
                        finish()
                    }
                }.show()
            return false
        }
        val input = EditText(this).apply {
            hint = "Enter PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("My Money – PIN")
            .setMessage("Enter your PIN to continue.")
            .setView(input).setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text.toString() == saved) {
                    loadEntries()
                    showHome()
                } else {
                    Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }.setNegativeButton("Exit") { _, _ -> finish() }.show()
        return false
    }

    private fun loadEntries() {
        entries.clear()
        val raw = prefs.getString("entries", "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            entries.add(Entry(o.getString("type"), o.getLong("amount"), o.optString("category"),
                o.optString("note"), o.getString("date")))
        }
    }

    private fun saveEntries() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().put("type", it.type).put("amount", it.amount)
                .put("category", it.category).put("note", it.note).put("date", it.date))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }

    private fun label(my: String, en: String) = if (english) en else my
    private fun money(n: Long) = "%,d Ks".format(n)

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "My Money"; textSize = 27f; setTextColor(0xFF146B3B.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val lang = Button(this).apply {
            text = if (english) "မြန်မာ" else "English"
            setOnClickListener { english = !english; showHome() }
        }
        header.addView(lang)
        root.addView(header)

        val income = entries.filter { it.type == "IN" }.sumOf { it.amount }
        val expense = entries.filter { it.type == "OUT" }.sumOf { it.amount }
        val card = TextView(this).apply {
            text = "${label("လက်ကျန်ငွေ", "Balance")}\n${money(income-expense)}\n\n${label("ဝင်ငွေ", "Income")}: ${money(income)}     ${label("ထွက်ငွေ", "Expense")}: ${money(expense)}"
            textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF176B43.toInt())
        }
        val cp = LinearLayout.LayoutParams(-1, -2); cp.setMargins(0, 18, 0, 18); root.addView(card, cp)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addIn = Button(this).apply { text = label("ဝင်ငွေ +", "Income +"); setOnClickListener { addEntry("IN") } }
        val addOut = Button(this).apply { text = label("ထွက်ငွေ −", "Expense −"); setOnClickListener { addEntry("OUT") } }
        actions.addView(addIn, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(addOut, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)

        val monthTitle = TextView(this).apply {
            text = label("ဒီလစာရင်း", "This month")
            textSize = 20f; setTextColor(0xFF222222.toInt()); setPadding(0, 20, 0, 8)
        }
        root.addView(monthTitle)
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        val mi = entries.filter { it.date.startsWith(month) && it.type == "IN" }.sumOf { it.amount }
        val mo = entries.filter { it.date.startsWith(month) && it.type == "OUT" }.sumOf { it.amount }
        addLine("${label("လစဉ်ဝင်ငွေ", "Monthly income")}: ${money(mi)}")
        addLine("${label("လစဉ်ထွက်ငွေ", "Monthly expense")}: ${money(mo)}")
        addLine("${label("လက်ကျန်", "Monthly balance")}: ${money(mi-mo)}")

        val historyTitle = TextView(this).apply {
            text = label("မှတ်တမ်းများ", "History")
            textSize = 20f; setTextColor(0xFF222222.toInt()); setPadding(0, 22, 0, 8)
        }
        root.addView(historyTitle)
        if (entries.isEmpty()) addLine(label("စာရင်းမရှိသေးပါ", "No transactions yet"))
        entries.asReversed().forEach { e ->
            val sign = if (e.type == "IN") "+" else "−"
            addLine("${e.date}  •  ${e.category}\n${e.note}\n$sign${money(e.amount)}")
        }

        val backup = Button(this).apply {
            text = label("Backup ဖိုင်ထုတ်ရန်", "Export backup")
            setOnClickListener { exportBackup() }
        }
        root.addView(backup)
        val restore = Button(this).apply {
            text = label("Backup ပြန်သွင်းရန်", "Import backup")
            setOnClickListener { importBackup() }
        }
        root.addView(restore)
    }

    private fun addLine(text: String) {
        val t = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(0xFF333333.toInt()); setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 4, 0, 4); root.addView(t, p)
    }

    private fun addEntry(type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
        val amount = EditText(this).apply { hint = label("ငွေပမာဏ (ကျပ်)", "Amount (Ks)"); inputType = InputType.TYPE_CLASS_NUMBER }
        val category = EditText(this).apply { hint = label("အမျိုးအစား", "Category") }
        val note = EditText(this).apply { hint = label("မှတ်ချက်", "Note") }
        box.addView(amount); box.addView(category); box.addView(note)
        AlertDialog.Builder(this).setTitle(if (type == "IN") label("ဝင်ငွေထည့်ရန်", "Add income") else label("ထွက်ငွေထည့်ရန်", "Add expense"))
            .setView(box).setPositiveButton(label("သိမ်းမယ်", "Save")) { _, _ ->
                val n = amount.text.toString().toLongOrNull()
                if (n == null || n <= 0) {
                    Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                } else {
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    entries.add(Entry(type, n, category.text.toString().ifBlank { "Other" }, note.text.toString(), date))
                    saveEntries(); showHome()
                }
            }.setNegativeButton(label("မလုပ်တော့", "Cancel"), null).show()
    }

    private fun exportBackup() {
        val text = prefs.getString("entries", "[]") ?: "[]"
        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_TITLE, "mymoney-backup.json")
        }
        backupText = text
        startActivityForResult(intent, 10)
    }
    private var backupText = "[]"

    private fun importBackup() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "application/json"
        }
        startActivityForResult(intent, 11)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            if (requestCode == 10) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupText.toByteArray()) }
                Toast.makeText(this, "Backup exported", Toast.LENGTH_SHORT).show()
            } else if (requestCode == 11) {
                val content = contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } ?: "[]"
                val arr = JSONArray(content)
                prefs.edit().putString("entries", arr.toString()).apply()
                loadEntries(); showHome()
                Toast.makeText(this, "Backup restored", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Backup error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
